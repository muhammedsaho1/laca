# LACA

Website for LACA (Accountancy and Consultancy Associates).

## Add photos
1. Upload photos into the `images` folder.
2. In `index.html`, add them to `IMG` and `SLIDES` near the bottom.

## Logo (final, locked)
- `images/logo.svg` – final LACA logo (sharp at any size)
- `images/logo.png` – high-resolution PNG with transparent background
- `logo_source.py` – the exact shapes, colours and sizes used to draw it (kept for reference; do not change)
